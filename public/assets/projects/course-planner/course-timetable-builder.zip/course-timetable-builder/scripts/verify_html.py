#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_html.py — 校验「已填好数据的」 course-timetable-builder HTML 是否合法。

检查项：
  1. 6 个占位符是否全部替换（无残留 __X__）
  2. SECTIONS / SCOPES / GROUPS / PRESET 是否都是可解析的 JSON
  3. SCOPES 是否含 key:'all' 且 mods:null（汇总视图依赖）
  4. 每门课的 g 是否都在 GROUPS.key 中
  5. PRESET 里的班次 ID 是否都能在 SECTIONS 找到
  6. 统计同一日期上的时间冲突对数（仅提示，不阻断）

用法：
  python verify_html.py 生成的文件.html
"""
import sys
import re
import json
import ast


def grab(html, name):
    s = html.index("const " + name)
    i = html.index("[", s)
    depth = 0
    p = i
    while p < len(html):
        if html[p] == "[":
            depth += 1
        elif html[p] == "]":
            depth -= 1
            if depth == 0:
                j = p
                break
        p += 1
    raw = html[i : j + 1]
    try:
        return json.loads(raw)  # 标准 JSON（SECTIONS 由 json.dumps 生成）
    except json.JSONDecodeError:
        # 容忍单引号 + 未加引号 key 的 JS 字面量（SCOPES/GROUPS/PRESET）
        norm = re.sub(r"([A-Za-z_][A-Za-z0-9_]*)\s*:", r'"\1":', raw)
        norm = norm.replace("null", "None").replace("true", "True").replace("false", "False")
        return ast.literal_eval(norm)


def overlap(a, b):
    return a[0] < b[1] and b[0] < a[1]


def main(path):
    html = open(path, encoding="utf-8").read()

    placeholders = [
        "__SECTIONS__",
        "__SCOPES__",
        "__GROUPS__",
        "__PRESET__",
        "__PLAN_KEY__",
        "__PROGRAM_NAME__",
    ]
    left = [p for p in placeholders if p in html]
    assert not left, f"✗ 还有未替换的占位符：{left}"

    S = grab(html, "SECTIONS")
    SC = grab(html, "SCOPES")
    GR = grab(html, "GROUPS")
    PR = grab(html, "PRESET")

    errs = []

    # 3. all scope
    all_scope = [x for x in SC if x.get("key") == "all"]
    if not all_scope:
        errs.append("SCOPES 缺少 key:'all' 的汇总条目")
    elif all_scope[0].get("mods") is not None:
        errs.append("key:'all' 的条目的 mods 必须为 null")

    # 4. g in GROUPS
    gkeys = {g["key"] for g in GR}
    bad_g = [s["code"] + "-" + s["label"] for s in S if s.get("g") not in gkeys]
    if bad_g:
        errs.append(f"课程的 g 不在 GROUPS 中：{bad_g[:5]}{'...' if len(bad_g) > 5 else ''}")

    # 5. PRESET ids exist
    ids = {x["code"] + "-" + x["label"] for x in S}
    bad_p = [p for p in PR if p not in ids]
    if bad_p:
        errs.append(f"PRESET 里有不存在的班次 ID：{bad_p}")

    # 6. conflicts
    bydate = {}
    for s in S:
        for se in s["sessions"]:
            bydate.setdefault(se["d"], []).append(
                (s["code"] + "-" + s["label"], se["s"])
            )
    conflicts = 0
    for d, items in bydate.items():
        for a in range(len(items)):
            for b in range(a + 1, len(items)):
                if items[a][0] != items[b][0] and any(
                    overlap(x, y) for x in items[a][1] for y in items[b][1]
                ):
                    conflicts += 1

    if errs:
        print("✗ 校验未通过：")
        for e in errs:
            print("  -", e)
        raise SystemExit(1)

    print(
        f"✓ 校验通过 | 班次 {len(S)} · 阶段 {len(SC)} · 分组 {len(GR)} · 推荐 {len(PR)} · 时间冲突 {conflicts} 对"
    )
    if conflicts:
        print("  （冲突仅为提示：同一日期时间重叠的班次会被标红，属正常排课约束）")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(1)
    main(sys.argv[1])
