#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_sections.py — 把「扁平课表 CSV」汇总成 course-timetable-builder 的 __SECTIONS__ JSON。

输入 CSV：每行 = 一个「课程班次 × 一次上课」。
列（表头必须包含，顺序不限）：
  code    课程代码，如 MFIN7002
  title   课程名称
  type    Core | Elective | Capstone
  g       分组键，需与 GROUPS.key 对应，如 m1
  mods    学期序号，逗号分隔，如 1 或 1,3
  label   班次字母，如 E
  venue   上课地点
  date    上课日期 YYYY-MM-DD
  start   开始时间 HH:MM（24h）
  end     结束时间 HH:MM
  dow     (可选) 文档声称的星期，如 Tue / 周二 / Monday，用于校验

用法：
  python extract_sections.py courses.csv sections.json
  python extract_sections.py courses.csv sections.json --check-dow   # 校验日期星期并报告不符

输出：sections.json，内容为可直接贴进模板 __SECTIONS__ 占位符的数组（缩进 2）。
"""
import csv
import json
import sys
import datetime

DOW_EN = {"mon": 1, "tue": 2, "wed": 3, "thu": 4, "fri": 5, "sat": 6, "sun": 7}
DOW_ZH = {"周一": 1, "周二": 2, "周三": 3, "周四": 4, "周五": 5, "周六": 6, "周日": 7}
DOW_NUM = {1: "周一", 2: "周二", 3: "周三", 4: "周四", 5: "周五", 6: "周六", 7: "周日"}


def to_min(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def dow_of(date_str):
    d = datetime.date.fromisoformat(date_str)
    return (d.weekday() + 1) % 7 or 7  # 1=周一..7=周日


def parse_dow(s):
    s = (s or "").strip().lower()
    if s in DOW_EN:
        return DOW_EN[s]
    if s in DOW_ZH:
        return DOW_ZH[s]
    # 容忍 "tuesday" / "星期三"
    for k, v in DOW_EN.items():
        if s.startswith(k):
            return v
    for k, v in DOW_ZH.items():
        if k in (s or ""):
            return v
    return None


def main(csv_path, out_path, check_dow=False):
    sections = {}
    warnings = []
    with open(csv_path, encoding="utf-8-sig") as f:
        for i, r in enumerate(csv.DictReader(f), 1):
            key = (r["code"].strip(), r["label"].strip())
            if key not in sections:
                mods = [int(x) for x in r["mods"].split(",") if x.strip() != ""]
                sections[key] = {
                    "code": r["code"].strip(),
                    "title": r["title"].strip(),
                    "type": r["type"].strip(),
                    "g": r["g"].strip(),
                    "mods": mods,
                    "label": r["label"].strip(),
                    "venue": r.get("venue", "").strip(),
                    "sessions": [],
                }
            d = r["date"].strip()
            try:
                start, end = to_min(r["start"].strip()), to_min(r["end"].strip())
            except Exception as e:
                raise SystemExit(f"第 {i} 行时间解析失败: {r.get('start')}-{r.get('end')} ({e})")
            sections[key]["sessions"].append({"d": d, "s": [[start, end]]})

            if check_dow and r.get("dow"):
                exp = parse_dow(r["dow"])
                real = dow_of(d)
                if exp and exp != real:
                    warnings.append(
                        f"  ⚠ 第{i}行 {r['code']}-{r['label']} {d} 真实是{DOW_NUM[real]}，"
                        f"文档写{DOW_NUM.get(exp, r['dow'])}"
                    )

    data = list(sections.values())
    for s in data:
        s["sessions"].sort(key=lambda x: x["d"])

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"✓ 写出 {len(data)} 个课程班次 -> {out_path}")
    if warnings:
        print(f"\n发现 {len(warnings)} 处日期/星期不符：")
        print("\n".join(warnings))
        print("\n（这些以哪个为准由你决定，但务必显式确认，否则课表星期会错）")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        raise SystemExit(1)
    chk = "--check-dow" in sys.argv
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]
    main(paths[0], paths[1], check_dow=chk)
