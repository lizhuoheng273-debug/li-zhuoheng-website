#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build.py — 把数据文件注入 template.html，生成最终可双击打开的排课页面。

用法：
  python build.py \
    --template assets/template.html \
    --sections sections.json \
    --scopes scopes.json \
    --groups groups.json \
    --preset preset.json \
    --name "MFFinTech 排课系统" \
    --plankey mffintech_plans_v1 \
    --out 排课系统.html

说明：
  - 各 JSON 文件内容即为对应占位符要填的数组（SECTIONS/SCOPES/GROUPS/PRESET）。
  - name / plankey 用 json.dumps 转义，避免破坏 JS 字符串。
  - 生成后用 verify_html.py 校验。
"""
import argparse
import json


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--template", required=True)
    ap.add_argument("--sections", required=True)
    ap.add_argument("--scopes", required=True)
    ap.add_argument("--groups", required=True)
    ap.add_argument("--preset", required=True)
    ap.add_argument("--name", required=True)
    ap.add_argument("--plankey", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    tpl = open(a.template, encoding="utf-8").read()
    sec = open(a.sections, encoding="utf-8").read().strip()
    sco = open(a.scopes, encoding="utf-8").read().strip()
    grp = open(a.groups, encoding="utf-8").read().strip()
    pre = open(a.preset, encoding="utf-8").read().strip()
    name = json.dumps(a.name, ensure_ascii=False)
    pk = json.dumps(a.plankey, ensure_ascii=False)

    repl = {
        "__SECTIONS__": sec,
        "__SCOPES__": sco,
        "__GROUPS__": grp,
        "__PRESET__": pre,
        "__PLAN_KEY__": pk,
        "__PROGRAM_NAME__": name,
    }
    for k, v in repl.items():
        assert k in tpl, f"模板缺少占位符 {k}"
        tpl = tpl.replace(k, v)  # 占位符可能出现多次（如 __PROGRAM_NAME__ 在 title 与 h1）
    # 兜底：不应再有占位符残留
    left = [k for k in repl if k in tpl]
    assert not left, f"仍有未替换占位符：{left}"

    open(a.out, "w", encoding="utf-8").write(tpl)
    print(f"✓ 已生成 {a.out}（{len(tpl)} 字节）")


if __name__ == "__main__":
    main()
