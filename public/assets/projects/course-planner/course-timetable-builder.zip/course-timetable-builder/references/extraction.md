# 从课程文档提取数据 —— course-timetable-builder

目标：把学校发的 Teaching Plan / 教学计划 / 校历 PDF，转成 `__SECTIONS__` 等数据。

## 整体流程

1. **拿到源文档**：教学计划（每门课的上课日期、星期、时间、班次）、校历（学期/Module 起止）、选课 FAQ（必修/选修结构）。
2. **抽出「扁平课表」**：一张表，每行 = 一个「课程班次 × 一次上课」。列：`code, title, type, g, mods, label, venue, date, start, end`。
3. **用 `scripts/extract_sections.py` 汇总**成 `__SECTIONS__` JSON。
4. **手写 `__SCOPES__` / `__GROUPS__`**：按你们专业的学期结构定义（参考 schema.md）。
5. **填 `__PRESET__`**：挑一套无冲突的推荐组合。
6. **用 `scripts/verify_html.py` 校验**生成的 HTML。

---

## 第 2 步：怎么得到扁平课表

Teaching Plan 常见两种版式：

- **表格版**（每门课一行，列含 Class Dates / Time / Venue）：用 Python `pdfplumber` 的 `extract_tables()` 直接拿。
- **文本/列表版**（「MFIN7002  Tue 14:00–17:00  Jan 23,30 Feb 13…」）：用 `PyMuPDF`（`fitz`）提取文本，按课程块正则切分。

推荐用 `PyMuPDF`：

```python
import fitz
doc = fitz.open("TeachingPlan.pdf")
text = "\n".join(page.get_text() for page in doc)
```

然后把每门课的「星期 + 时间 + 日期列表」解析出来，展开成多行（每个日期一行）。

### 时间解析

`"14:00–17:00"` → `[[840, 1020]]`；同一天两节如 `"09:00–12:00, 14:00–17:00"` → `[[540,720],[840,1020]]`。
`HH:MM` → 分钟：`int(HH)*60 + int(MM)`。

### 日期解析

教学计划常写「Jan 23, 30 / Feb 13, 20, 27」这种「月 + 若干日」。按年份展开成 `YYYY-MM-DD`。跨年注意（春季学期常跨 1 月）。

---

## ⚠️ 最大的坑：日期与星期对不上

真实案例：某课 Teaching Plan 写 **「Tuesday」**，但列出的日期按公历全是**周六**（1/23、1/30…）。这是源文档本身的错误。

**必须做星期校验**：拿到 `date` 后，用代码算出它的真实星期，和文档声称的星期比对；不一致就**人工确认**以哪个为准，不要直接照搬。

```python
import datetime
def dow_of(date_str):  # 'YYYY-MM-DD' -> 0=Mon..6=Sun
    d = datetime.date.fromisoformat(date_str)
    return (d.weekday() + 1) % 7  # 1=Mon
```

> 本项目当时选择「按文档文字的 Tuesday 把日期前推 4 天到同周周二」；后来回滚到「保留原始周六日期」。结论：**以哪个为准由你决定，但一定要显式校验并标注**，否则课表星期会错。

---

## 跨学期 / 跨 Module 班

有些班横跨多个 Module（如 LLAW6093 跨 M3–M5）。处理：

- `mods` 写多个序号：`[3,4,5]`。
- `g` 可以指向一个专门的「跨 Module」分组（在 `__GROUPS__` 里加一条 `mods:[3,4,5]`）。
- 这样在对应阶段标签下它都可见，且真实日期由 `sessions` 决定展示位置。

---

## 第 3 步：跑汇总脚本

把扁平课表存成 `courses.csv`（列见 schema.md / 脚本头注释），运行：

```bash
python scripts/extract_sections.py courses.csv sections.json
```

脚本会按 `(code, label)` 聚合出 `__SECTIONS__`，并可选校验星期。把 `sections.json` 的内容贴进模板的 `__SECTIONS__` 占位符。

---

## 第 4 步：SCOPES / GROUPS

照你们专业的真实学期结构写。示例（HKU MFFinTech 的 6 个 Module 两学期制）：

```js
const SCOPES=[
  {key:'sem1',name:'学期1（M1–M2）',mods:[1,2],range:'...'},
  {key:'sem2',name:'学期2（M3–M4）',mods:[3,4],range:'...'},
  {key:'late',name:'下学期（M5–M6）',mods:[5,6],range:'...'},
  {key:'all', name:'全部（汇总）',mods:null,range:'完整学年'}
];
const GROUPS=[
  {key:'s1',name:'学期 1（Module 1–2）',mods:[1,2]},
  {key:'m1',name:'Module 1',mods:[1]},
  {key:'m2',name:'Module 2',mods:[2]},
  {key:'s2',name:'学期 2 · 跨 Module 班',mods:[3,4,5]},
  {key:'m3',name:'Module 3',mods:[3]},
  {key:'m4',name:'Module 4',mods:[4]}
];
```

---

## 第 6 步：校验生成结果

```bash
python scripts/verify_html.py 生成的文件.html
```

脚本会检查：占位符是否全部替换、SCOPES 是否含 `all`、每门课的 `g` 是否都在 GROUPS、PRESET 的 ID 是否都存在，并统计时间冲突对数。全部通过才交付。
