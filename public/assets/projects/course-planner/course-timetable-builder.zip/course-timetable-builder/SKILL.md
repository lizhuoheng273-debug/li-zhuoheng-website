---
name: course-timetable-builder
description: |
  This skill should be used when a user wants to build an interactive
  course-selection / timetable planner from a university program's course list
  or teaching-plan PDFs — to visualize weekly schedules, detect time conflicts,
  plan around internships or part-time work, and save/compare multiple plans.
  It works for any major or school once the course data is supplied. Trigger on
  requests like "帮我做个排课系统/选课页面", "把教学计划做成可交互的课表",
  "generate a course timetable planner from this PDF", or when a student from
  any program wants to see how to arrange their courses across terms.
agent_created: true
---

# Course Timetable Builder

Generate a **single-file, dependency-free HTML** course-scheduling page. A
student picks course sections, sees a date-accurate weekly calendar, gets
time-conflict highlighting, and can save/compare multiple plans (e.g. one
internship-friendly arrangement vs. one that finishes early). The same skill
works for any program: only the data changes.

## What the output page does

- Left panel lists courses grouped by term/Module (driven by `GROUPS`).
- Clicking a section (A/B/C/D班) drops it onto the right-side weekly grid;
  the view auto-jumps to the term it belongs to.
- Real class **dates** are shown; navigate week-by-week (‹ › buttons / arrow
  keys) across the whole academic year.
- Picking a section that overlaps an already-picked one on the same date turns
  it red / greys it out (conflict detection).
- "保存方案" stores the current selection to `localStorage` (key `__PLAN_KEY__`);
  saved plans appear as cards and can be re-imported or deleted.

## When to use

- The user supplies (or has) a program's teaching plan / course list / academic
  calendar, and wants a visual, interactive planner.
- The user is helping a classmate from a different major build their own page.
- The goal is to arrange courses to leave free weekdays for an internship, or
  to compare "dense vs. spread" schedules.

## Workflow

### 1. Gather source documents
Collect: teaching plan (per-course class dates, weekdays, times, sections),
academic calendar (term/Module start–end), and the program's required/elective
structure. These need not be machine-readable yet.

### 2. Define the term structure → `SCOPES` and `GROUPS`
Decide how the program splits the year (semesters, trimesters, Modules). Write
`SCOPES` (top tabs) and `GROUPS` (left-list groupings) by hand, following
`references/schema.md`. **One `SCOPES` entry must have `key:"all"` and
`mods:null`** (the full-year view depends on it).

### 3. Extract `SECTIONS` from the teaching plan
Build a flat CSV, one row per (course-section × class session):
`code,title,type,g,mods,label,venue,date,start,end[,dow]`
Then run:

```bash
python scripts/extract_sections.py courses.csv sections.json --check-dow
```

The `--check-dow` flag validates that each `date` actually falls on the weekday
the document claims — **this catches the classic "Tuesday written but dates are
Saturdays" mismatch** (see `references/extraction.md`). The script groups rows
into `SECTIONS` JSON.

### 4. Fill the remaining placeholders
- `__PROGRAM_NAME__`: page title (e.g. "MFFinTech 排课系统").
- `__PRESET__`: an array of section IDs (`code-label`) for the one-click
  recommended plan (can be `[]`).
- `__PLAN_KEY__`: any unique string for localStorage (e.g. `mffintech_plans_v1`).

### 5. Generate the HTML
Use `scripts/build.py` to inject everything into `assets/template.html`:

```bash
python scripts/build.py \
  --template assets/template.html \
  --sections sections.json --scopes scopes.json --groups groups.json --preset preset.json \
  --name "MFFinTech 排课系统" --plankey mffintech_plans_v1 --out 排课系统.html
```

(If the user prefers, the 6 placeholders in `template.html` can also be edited
in place — they are clearly marked `__XXX__`.)

### 6. Validate
```bash
python scripts/verify_html.py 排课系统.html
```
Confirms all placeholders are filled, `SCOPES` has the `all` entry, every
course's `g` exists in `GROUPS`, every `PRESET` ID exists, and reports the
time-conflict count. Deliver the single HTML file.

## Reference files (load as needed)

- `references/schema.md` — exact field formats for all 6 placeholders, the
  minute-based time convention, conflict logic, and a minimal runnable example.
- `references/extraction.md` — detailed PDF-to-data workflow, weekday
  validation, cross-Module handling, and the SCOPES/GROUPS authoring notes.

## Key pitfalls

- **Date vs. weekday mismatch** in source PDFs: always run `--check-dow` and
  decide explicitly which to trust before filling data.
- **Times** are minutes from midnight (09:00 = 540). The grid shows 09:00–
  22:30 by default; adjust `const TOP=540, BOT=1350` in the template for
  earlier/later classes.
- Every course's `g` must match a `GROUPS.key`, or it won't appear in the list.
